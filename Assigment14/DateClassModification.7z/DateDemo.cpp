/* Date Demo - This is a modified version of the Date class, written for Programming 
					Challenge 13.1. */

#include "Date.h"

#include <iostream>
using std::cin;
using std::cout;

int main()
{
	cout << "MODIFIED DATE CLASS DEMO\n\n"
		  << "This program demonstrates various abilities of the modified\n"
		  << "Date class, written for Programming Challenge 13.1.\n\n";

	cout << "Demonstrating the output of a date in three different styles:\n";
	Date date(2009, 6, 7);
	date.printFormatOne();
	date.printFormatTwo();
	date.printFormatThree();

	cout << "\n\nDemonstrating the overloaded Prefix ++ operator:\n";
	Date dateOne(2018, 12, 27);
	cout << "The date is:     " << dateOne << "\n";
	++dateOne;
	cout << "The new date is: " << dateOne << "\n\n";

	cout << "Demonstrating the overloaded Postfix ++ operator:\n";
	Date dateTwo(2017, 11, 26);
	cout << "The date is:     " << dateTwo << "\n";
	dateTwo++;
	cout << "The new date is: " << dateTwo << "\n\n";

	cout << "Demonstrating the overloaded Prefix -- operator:\n";
	Date dateThree(2012, 1, 1);
	cout << "The date is:     " << dateThree << "\n";
	--dateThree;
	cout << "The new date is: " << dateThree << "\n\n";

	cout << "Demonstrating the overloaded Postfix -- operator:\n";
	Date dateFour(2012, 3, 1);
	cout << "The date is:     " << dateFour << "\n";
	dateFour--;
	cout << "The new date is: " << dateFour << "\n\n";

	cout << "Demonstrating the overloaded Extraction operator:\n\n";
	Date dateFive;
	cin >> dateFive;
	cout << "\nThis is the date you entered: " << dateFive << "\n\n";

	cout << "Demonstrating the overloaded Binary - operator:\n\n";
	cout << "The difference in days between \n"
		  << dateFive << " and " << dateTwo << " is: ";
	dateFive = dateFive - dateTwo;
	cout << dateFive.getDifference() << " days.\n\n";

	cout << "Thank you for trying the Date class demo. Have a nice day!";

	cin.ignore();
	cin.get();
   return 0;
}